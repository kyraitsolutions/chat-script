globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/5e9cd_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6917b828._.js",
    "static/chunks/5e9cd_next_dist_compiled_react-dom_43c1f426._.js",
    "static/chunks/5e9cd_next_dist_compiled_react-server-dom-turbopack_e2397ea1._.js",
    "static/chunks/5e9cd_next_dist_compiled_next-devtools_index_f4472ecb.js",
    "static/chunks/5e9cd_next_dist_compiled_ea9a69f4._.js",
    "static/chunks/5e9cd_next_dist_client_942f9e24._.js",
    "static/chunks/5e9cd_next_dist_f1068c99._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_0ec3d3fa._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];