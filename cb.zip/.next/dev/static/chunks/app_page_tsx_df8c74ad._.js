(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/5e9cd_next_5ca91d0a._.js",
  "static/chunks/034c8_react-icons_tb_index_mjs_e68b6c43._.js",
  "static/chunks/034c8_react-icons_rx_index_mjs_3c05fefe._.js",
  "static/chunks/034c8_react-icons_lib_45326482._.js",
  "static/chunks/_c7d8191b._.js"
],
    source: "dynamic"
});
